import 'package:flutter/material.dart';
import 'questions.dart';

class HomeScreen extends StatefulWidget {
  final bool isDarkMode;
  final VoidCallback onThemeToggle;

  const HomeScreen({
    super.key,
    required this.isDarkMode,
    required this.onThemeToggle,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late List<Question> shuffledQuestions;
  int currentIndex = 0;
  String? selectedOption; // "A", "B" or null
  bool quizFinished = false;

  int answeredCount = 0;
  int skippedCount = 0;

  @override
  void initState() {
    super.initState();
    // fresh shuffle every time this screen opens (every playthrough)
    shuffledQuestions = List.from(questionList)..shuffle();
  }

  // runs when user taps option A or B
  void selectOption(String option) {
    if (selectedOption != null) return; // already answered

    setState(() {
      selectedOption = option;
      answeredCount++;
    });
  }

  // runs when Skip is tapped (only visible before answering)
  void skipQuestion() {
    if (selectedOption != null) return;
    setState(() {
      skippedCount++;
    });
    goToNextQuestion();
  }

  // runs when Next is tapped
  void goToNextQuestion() {
    if (currentIndex < shuffledQuestions.length - 1) {
      setState(() {
        currentIndex++;
        selectedOption = null;
      });
    } else {
      setState(() {
        quizFinished = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Would You Rather"),
        actions: [
          IconButton(
            icon: Icon(widget.isDarkMode ? Icons.dark_mode : Icons.light_mode),
            onPressed: widget.onThemeToggle,
          ),
        ],
      ),
      body: quizFinished
          ? buildFinishScreen(context)
          : buildQuestionScreen(context),
    );
  }

  // main quiz screen
  Widget buildQuestionScreen(BuildContext context) {
    Question question = shuffledQuestions[currentIndex];

    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              value: (currentIndex + 1) / shuffledQuestions.length,
              minHeight: 8,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "Question ${currentIndex + 1} of ${shuffledQuestions.length}",
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 30),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Text(
                question.text,
                style: const TextStyle(fontSize: 20),
                textAlign: TextAlign.center,
              ),
            ),
          ),
          const SizedBox(height: 30),

          buildOptionButton(context, "A", question.optionA),
          const SizedBox(height: 12),
          buildOptionButton(context, "B", question.optionB),
          const SizedBox(height: 20),

          // skip button shows only before answering, next shows after
          if (selectedOption == null)
            TextButton(
              onPressed: skipQuestion,
              child: const Text("Skip"),
            )
          else
            ElevatedButton(
              onPressed: goToNextQuestion,
              child: const Text("Next"),
            ),
        ],
      ),
    );
  }

  // builds option A and option B buttons with the soft selected color
  Widget buildOptionButton(BuildContext context, String option, String label) {
    bool isSelected = selectedOption == option;
    final colors = Theme.of(context).colorScheme;

    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor:
            isSelected ? colors.primary : colors.surfaceContainerHighest,
        foregroundColor: isSelected ? colors.onPrimary : colors.onSurface,
      ),
      onPressed: () => selectOption(option),
      child: Text(label),
    );
  }

  // shown after the last question
  Widget buildFinishScreen(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.celebration_outlined,
              size: 70,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 20),
            Text(
              "You finished the quiz!",
              style: Theme.of(context).textTheme.headlineSmall,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Text("Answered: $answeredCount    Skipped: $skippedCount"),
            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Play Again"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
