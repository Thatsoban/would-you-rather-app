// This file just holds all our questions in a simple list

class Question {
  String text;
  String optionA;
  String optionB;

  Question(this.text, this.optionA, this.optionB);
}

List<Question> questionList = [
  Question("Would you rather have the ability to fly or be invisible?", "Fly",
      "Be Invisible"),
  Question("Would you rather always be 10 minutes late or 20 minutes early?",
      "Always Late", "Always Early"),
  Question("Would you rather live without music or without TV?", "No Music",
      "No TV"),
  Question("Would you rather have unlimited money or unlimited time?",
      "Unlimited Money", "Unlimited Time"),
  Question("Would you rather know when you will die or how you will die?",
      "Know When", "Know How"),
  Question("Would you rather eat pizza every day or never eat pizza again?",
      "Pizza Every Day", "No Pizza Ever"),
  Question(
      "Would you rather be the smartest person in the room or the funniest?",
      "Smartest",
      "Funniest"),
  Question("Would you rather travel to the past or to the future?", "Past",
      "Future"),
  Question("Would you rather have super strength or super speed?",
      "Super Strength", "Super Speed"),
  Question("Would you rather lose your phone or your wallet?", "Lose Phone",
      "Lose Wallet"),
  Question(
      "Would you rather sleep 4 hours every night or 12 hours every night?",
      "4 Hours",
      "12 Hours"),
  Question("Would you rather be famous but poor or rich but unknown?",
      "Famous Poor", "Rich Unknown"),
  Question("Would you rather give up coffee or give up your phone?",
      "Give Up Coffee", "Give Up Phone"),
  Question("Would you rather live in a big city or a small village?",
      "Big City", "Small Village"),
  Question("Would you rather always say what you think or never speak again?",
      "Say Everything", "Never Speak"),
];
